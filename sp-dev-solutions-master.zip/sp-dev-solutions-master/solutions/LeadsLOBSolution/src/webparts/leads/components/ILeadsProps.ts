export interface ILeadsProps {
  description: string;
}
