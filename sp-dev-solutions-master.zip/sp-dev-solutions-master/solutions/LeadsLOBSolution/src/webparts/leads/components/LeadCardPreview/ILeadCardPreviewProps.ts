import { IDocumentCardPreviewImage } from "office-ui-fabric-react/lib/DocumentCard";

export interface ILeadCardPreviewProps {
  previewItems: IDocumentCardPreviewImage[];
}