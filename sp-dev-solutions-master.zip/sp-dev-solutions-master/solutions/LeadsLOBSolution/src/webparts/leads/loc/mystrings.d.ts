declare interface ILeadsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LeadsWebPartStrings' {
  const strings: ILeadsWebPartStrings;
  export = strings;
}
