/// <reference types="mocha" />

import { assert } from 'chai';

describe('BoxButtonWebPartWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
