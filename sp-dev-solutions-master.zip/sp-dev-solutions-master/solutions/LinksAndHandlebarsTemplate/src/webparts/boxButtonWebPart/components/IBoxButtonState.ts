export interface IBoxButtonState{
}