export interface IBoxButton{
    name:string;
    url: string;
    icon: string;
    isBlue: boolean;
    openNew: boolean;
}