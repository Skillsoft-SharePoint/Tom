export interface IFeaturedContentState{
    isLinkPanelOpen: boolean;
    isSiteSelected: boolean;
    linkValid: boolean;
    linkEntered: string;
}