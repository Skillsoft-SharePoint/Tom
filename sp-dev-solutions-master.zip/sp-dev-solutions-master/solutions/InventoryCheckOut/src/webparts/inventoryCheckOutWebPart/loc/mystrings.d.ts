declare interface IInventoryCheckOutWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'inventoryCheckOutWebPartStrings' {
  const strings: IInventoryCheckOutWebPartStrings;
  export = strings;
}
