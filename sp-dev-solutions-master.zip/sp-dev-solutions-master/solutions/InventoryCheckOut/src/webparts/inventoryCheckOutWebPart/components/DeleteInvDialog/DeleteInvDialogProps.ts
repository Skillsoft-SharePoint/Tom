// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

interface DeleteInvDialogProps {
    showDialog: boolean;
    itemDeleteConfirmOperationCallback: any;
    title:string;
}

export default DeleteInvDialogProps;