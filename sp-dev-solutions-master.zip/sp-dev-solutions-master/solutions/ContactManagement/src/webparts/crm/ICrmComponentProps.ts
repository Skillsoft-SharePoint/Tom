// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

import CrmManager from '../../data/CrmManager';

export interface ICrmComponentProps {
  manager : CrmManager;
}
