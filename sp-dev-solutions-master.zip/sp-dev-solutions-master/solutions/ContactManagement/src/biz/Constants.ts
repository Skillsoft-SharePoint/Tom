export class Constants{
   public static readonly ContactManagementOrganizationListTitle: string = "Organizations";
   public static readonly ContactManagementContactsListTitle: string = "Contacts";
   public static readonly ContactManagementTagListTitle: string = "Tags";
}