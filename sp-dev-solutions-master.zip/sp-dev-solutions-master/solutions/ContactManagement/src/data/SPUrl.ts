// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

export default class SPUrl {
    public Url: string;
    public Description: string;
}
