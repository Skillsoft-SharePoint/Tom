# About

Column Formatter was created by [Chris Kent](https://thechriskent.com). It is distributed as part of SharePoint Patterns & Practices (PnP) and is totally free!

Got an idea? Spotted a bug? [Contributions](../../../projectguides/contributing.md) are always welcome!

## Additional Contributors

- [PooLP](http://www.poolp.net/)
    - Provided French Localization
- [Thomas Goelles](http://www.modernworkplacesolutions.rocks/)
    - Provided German Localization

> Go [Home](../index.md)

![](https://telemetry.sharepointpnp.com/sp-dev-solutions/solutions/ColumnFormatter/wiki/About)