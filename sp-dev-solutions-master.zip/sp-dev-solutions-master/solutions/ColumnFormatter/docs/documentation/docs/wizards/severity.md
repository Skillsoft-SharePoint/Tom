# Severity

Conditionally applies the severity styles based on the field's value.

![Severity Wizard](../assets/WizardSeverity.png)

## How to use this wizard

_Coming Soon_

## Supported column types
- Text
- Choice
- Lookup

## Icon

![Icon](../assets/icons/Info.png)

> [Wizards](./index.md)

> Go [Home](../index.md)

![](https://telemetry.sharepointpnp.com/sp-dev-solutions/solutions/ColumnFormatter/wiki/Wizards/Severity)