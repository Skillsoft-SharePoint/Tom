# Mail To

Creates a link to launch an email.

![Mail To Wizard](../assets/WizardMailTo.png)

## How to use this wizard

_Coming Soon_

## Supported column types
- Person
- Hyperlink

## Icon

![Icon](../assets/icons/Mail.png)

> [Wizards](./index.md)

> Go [Home](../index.md)

![](https://telemetry.sharepointpnp.com/sp-dev-solutions/solutions/ColumnFormatter/wiki/Wizards/MailTo)