declare interface IChangeRequestManagementWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'changeRequestManagementWebPartStrings' {
  const strings: IChangeRequestManagementWebPartStrings;
  export = strings;
}
