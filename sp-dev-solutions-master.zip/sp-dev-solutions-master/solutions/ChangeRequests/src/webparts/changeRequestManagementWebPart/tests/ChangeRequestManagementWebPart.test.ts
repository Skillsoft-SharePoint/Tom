/// <reference types="mocha" />

import { assert } from 'chai';

describe('ChangeRequestManagementWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
