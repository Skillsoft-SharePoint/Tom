export interface IChangeRequestManagementWebPartProps {
}
