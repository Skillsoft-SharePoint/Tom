import { ItemOperationCallback } from '../../models/ItemOperationCallback';
interface IMyCRHintDialogProps {
    newcrsubmissiontext: string;
    isOpen: boolean;
    itemCloseOperationCallback: ItemOperationCallback;
}
export default IMyCRHintDialogProps;