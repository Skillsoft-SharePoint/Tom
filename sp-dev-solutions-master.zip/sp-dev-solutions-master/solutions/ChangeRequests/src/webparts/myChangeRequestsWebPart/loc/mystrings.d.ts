declare interface IMyChangeRequestsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'myChangeRequestsWebPartStrings' {
  const strings: IMyChangeRequestsWebPartStrings;
  export = strings;
}
