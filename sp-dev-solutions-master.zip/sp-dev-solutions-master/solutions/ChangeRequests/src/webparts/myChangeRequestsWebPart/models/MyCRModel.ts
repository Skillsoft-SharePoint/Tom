export enum NewCRDialogShowType {
    Closed = 0,
    Dialog
}

export enum NewCRDisplays {
    PopUp= 1,
    Inline
}

export enum NewCRFormShowIn {
    Dialog= 1,
    Inline
}