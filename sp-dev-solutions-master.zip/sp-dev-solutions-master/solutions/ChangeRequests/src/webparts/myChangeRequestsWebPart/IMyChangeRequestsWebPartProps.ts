export interface IMyChangeRequestsWebPartProps {
  newcrdisplays: string;
  newcrtext: string;
  newcrsubmissiontext: string;
  newcrbuttontext: string;
}
