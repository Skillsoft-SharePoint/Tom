/// <reference types="mocha" />

import { assert } from 'chai';

describe('MyChangeRequestsWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
