/* tslint:disable */
require('./GetSpListItems.module.css');
const styles = {
  helloWorld: 'helloWorld_d123f0be',
  container: 'container_d123f0be',
  row: 'row_d123f0be',
  listItem: 'listItem_d123f0be',
  button: 'button_d123f0be',
  label: 'label_d123f0be',
};

export default styles;
/* tslint:enable */