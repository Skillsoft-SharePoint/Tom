export interface IGetSpListItemsWebPartProps {
  description: string;
}
