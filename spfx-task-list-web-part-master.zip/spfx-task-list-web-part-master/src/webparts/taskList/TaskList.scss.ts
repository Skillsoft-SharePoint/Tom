/* tslint:disable */
require('./TaskList.css');

/* tslint:enable */